  <?php get_header(); ?>

 <!-- banner section -->
 <?php  get_template_part('partials/banner'); ?>
    <!--banner section end -->


  <!-- SERVICES -->
 <?php  get_template_part('partials/servicios'); ?>
  <!-- END SERVICES -->
  <!-- ABOUT -->
<?php  get_template_part('partials/about'); ?>
  <!-- END ABOUT -->
  <!-- Team -->
 <?php  get_template_part('partials/team'); ?>
  <!-- END TEAM -->
  <!-- PROJETCS -->
 <?php  get_template_part('partials/project'); ?>
 
  <!-- END PROJECTS -->

  <!-- testimonies -->
  <?php  get_template_part('partials/testimonios'); ?>

  <!-- END testimonies -->

  <!-- PHRASE -->
 <?php  get_template_part('partials/phrase'); ?>

  <!-- END PHRASE -->

  <!-- BLOG -->
  <?php  get_template_part('partials/blog'); ?>
  <!-- END BLOG -->
  <!-- CLIENTS -->
   <?php  get_template_part('partials/clientes'); ?>
  <!-- END CLIENTS -->
 

     <?php get_footer(); ?>
