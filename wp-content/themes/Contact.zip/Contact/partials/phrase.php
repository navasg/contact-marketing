  <section class="phrase ">
    <div class="container padding-top-bottom">

      <div class="mask-banner">
        <h2>Invierte en Marketing de Performance <br> y potencia tus acciones
        </h2>
      </div>
    </div>

  </section>