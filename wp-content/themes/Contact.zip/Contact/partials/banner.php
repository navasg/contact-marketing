 <!-- BANNER HOME -->

  <!-- <div class="container-video">
    <% @banners.each do |banner|    %>
    <video autoplay="autoplay" class="video-banner" loop="true" poster="<%= banner.image.url %>"
      src="<%= banner.video.url %>"></video>
    <source src="<%= banner.video.url %>" type="video/mp4">
    </source>
    <div class="mask-banner">
      <div class="text-banner">
        <h2>Logramos tus objetivos <br> de forma eficiente</h2>
      </div>
    </div> -->
  <section class="banner-home">
    
    <  <video autoplay="autoplay" class="img-banner" loop="true" src="<?php echo get_template_directory_uri(); ?>/assets/video/Ipad - 2988.mp4"></video>

    <div class="mask-banner">
      <div class="text-banner">
        <h2>Logramos tus objetivos <br> de forma eficiente</h2>
      </div>
    </div>
    
  </section>
  <!-- END BANNER HOME -->